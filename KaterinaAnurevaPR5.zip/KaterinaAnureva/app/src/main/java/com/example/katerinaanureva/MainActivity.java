package com.example.katerinaanureva;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView katya;
    Button pushMe;

    int clickCount = 0;

    final View.OnClickListener obrobka = new View.OnClickListener() {
        public void onClick(View v) {
            clickCount++;
            if (clickCount == 1) {
                katya.setText("Button was pressed");
            } else if (clickCount == 2) {
                katya.setText("You've already pressed me");
            } else if (clickCount >= 3) {
                katya.setText("That's enough for me");
                pushMe.setEnabled(false);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        katya = findViewById(R.id.textView);
        pushMe = findViewById(R.id.button2);

        pushMe.setOnClickListener(obrobka);
        Toast.makeText(this, "Create", Toast.LENGTH_LONG).show();
    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        Toast.makeText(this, "Im on pause", Toast.LENGTH_LONG).show();
//    }
//
//
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        Toast.makeText(this, "I restart", Toast.LENGTH_LONG).show();
//          clickCount = 0;
//          katya.setText("Hello Katie");
//          pushMe.setEnabled(true);
//    }
//
//
//    @Override
//    protected void onStart() {
//        super.onStart();
//        Toast.makeText(this, "I work", Toast.LENGTH_LONG).show();
//    }

}
